﻿function cicektopla(thePlayer, cmd, text)
if getDistanceBetweenPoints3D(x,y,z, getElementPosition(thePlayer)) > 5 then
exports["vrp_infobox"]:addBox(thePlayer, "error", "Çiçek toplamak için uzaktasın!")
return
end
if text == "topla" then
if getElementData(thePlayer, "cicekte") then
return
end
setElementData(thePlayer, "cicekte", true)
exports.global:applyAnimation(thePlayer, "bomber", "bom_plant_loop", 5000, true, false, false)
setElementFrozen(thePlayer, true)
exports["vrp_infobox"]:addBox(thePlayer, "success", "Çiçek toplamaya başladınız!")
setTimer(
function(nothing)
setElementFrozen(thePlayer, false)
exports["vrp_infobox"]:addBox(thePlayer, "success", "Başarı ile çiçek topladınız!")
exports.global:giveItem(thePlayer, 1, 1)
setElementData(thePlayer, "cicekte", nil)
end, 5000, 1, true)
end
end
addCommandHandler("cicek", cicektopla)

function ciceksats (thePlayer,cmd,commands)
  if getDistanceBetweenPoints3D(x,y,z, getElementPosition(thePlayer)) > 5 then
  outputChatBox("gerekli alanda değilsin",thePlayer)
  return 
  end 
  
  if comands == "sat" then
      exports.global:giveMoney(thePlayer,25)
      exports.global:takeItem(thePlayer,cicekitemid)
      outputChatBox("başarılı sattın",thePlayer)    
  end
end 
addCommandHandler("cicek",ciceksats)

function sisteminfo (thePlayer,cmd,commands)
  outputChatBox("/cicek [topla, sat]",thePlayer)
end 
addCommandHandler("cicek",sisteminfo) 