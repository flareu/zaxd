﻿addEvent ("plakakaplama.onload", true);
addEvent ("plakakaplama.plakasatinal", true);

local mods = {};
addEventHandler ("onResourceStart", resourceRoot, function ()
	local meta = xmlLoadFile ("meta.xml")
	parseMeta(mods, meta)
end)


addEventHandler ("plakakaplama.onload", resourceRoot, function ()
	triggerLatentClientEvent (client, "plakakaplama.request", client, mods)
end)	

function parseMeta(tbl, meta)
	for i, v in ipairs (xmlNodeGetChildren(meta)) do 
		if xmlNodeGetName(v) == "file" then 
			local fiyat = tonumber (xmlNodeGetAttribute(v, "fiyat"))
			if fiyat then
				local file = xmlNodeGetAttribute (v, "src")
				table.insert (tbl, {file = file, fiyat = fiyat})
			end	
		end
	end	
end	

addEventHandler("plakakaplama.plakasatinal",resourceRoot,function(plakaid,fiyat)
	local arac = getPedOccupiedVehicle(client)
	if not isElement(arac) then outputChatBox("#000000[✘] #ffffffAraçta olmalısın",client,255,0,0, true) return end
	local aracplaka = getElementData(arac,"Aracplaka")
	if aracplaka and aracplaka == plakaid then outputChatBox("#000000[✘] #ffffffBu aracın plakası zatena aynı.",client,255,0,0, true) return end
	local oyuncupara = getPlayerMoney(client)
	if oyuncupara < fiyat then outputChatBox("#000000[✘] #ffffffBu plakayı alabilmek için yeterli paran yok.",client,255,0,0, true) return end
	setElementData(arac,"Aracplaka",plakaid)
	takePlayerMoney(client,fiyat)
	outputChatBox("#000000[✘] #ffffffBaşarıyla plaka oluşturuldu.",client,0,255,0, true)
end)