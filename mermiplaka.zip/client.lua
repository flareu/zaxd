arac_shader = {
	"yazi",
}

local araclar = {}


function shaderYap(arac,id)
	if isElement(araclar[arac]) then
		destroyElement(araclar[arac])
	end	
	araclar[arac] = dxCreateShader("plaka.fx", 1, 100,false,"vehicle")
	local plaka = dxCreateTexture( "plaka/plaka"..id..".png" )
	dxSetShaderValue(araclar[arac],"Tex01",plaka)
	for i=1,#arac_shader do
		engineApplyShaderToWorldTexture(araclar[arac],arac_shader[i],arac)
	end
end

function shaderKaldir(veh)
	if araclar[veh] then
		for _,texture in pairs(arac_shader) do
			engineRemoveShaderFromWorldTexture(araclar[veh], texture, veh)
		end
		if isElement(araclar[veh]) then destroyElement(araclar[veh]) end
		araclar[veh] = nil
	end
end

function streamIn()
	if getElementType( source ) == "vehicle" then
		local aracplaka = getElementData(source,"Aracplaka")
		if aracplaka then
			shaderYap(source,aracplaka or 1)
		end
	end
end

function streamOut()
	if getElementType( source ) == "vehicle" then
		shaderKaldir(veh)
	end
end

function dataChange(name, oldVaue)
	if getElementType( source ) ~= "vehicle" then return end
	if not isElementStreamedIn(source) then return end
	if name == "Aracplaka" then
		local aracplaka = getElementData(source,"Aracplaka")
		if aracplaka then
			shaderYap(source,aracplaka or 1)
		else		
			shaderKaldir(source)
		end
	end
end


addEventHandler("onClientElementStreamIn", root,streamIn)
addEventHandler("onClientElementStreamOut", root,streamOut)
addEventHandler("onClientElementDataChange", root,dataChange)