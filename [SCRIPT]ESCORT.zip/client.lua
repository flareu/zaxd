﻿function SkinYukle152()
    local txd = engineLoadTXD ('skin/htryn.txd')
    engineImportTXD(txd,152)
    local dff = engineLoadDFF('skin/htryn.dff',152)
    engineReplaceModel(dff,152)
end
addEventHandler('onClientResourceStart',getResourceRootElement(getThisResource()),SkinYukle152)