﻿function moneys (player, money)
takePlayerMoney(player, money)
end
addEvent( "money", true )
addEventHandler( "money", getRootElement(), moneys )

function worksJobEnterDoor(source)
	ped1 = createPed(152, 2258.4772949219, -1687.8142333984, 13.7)
	setElementFrozen ( source, true )
	setElementFrozen ( ped1, true )
	setPedAnimation(ped1, "ped", "turn_180")
	setPedRotation(ped1, 180)
	setPedRotation(source, 0)
	setElementPosition ( source, 2258.4462890625, -1688.1072998047, 13.7 )
	setPedAnimation( source, "PAULNMAC","Piss_in")
	setTimer(noanim,500,1,ped1)
	setTimer(anim,3500,1,ped1)
	setTimer(anim2,3500,1,source)
	setTimer(delPeds,35000,1,ped1)
	setTimer(delPeds1,35000,1,source)
	destroyElement(ped2)
end
addEvent("WorksJobEnterDoor",true)
addEventHandler("WorksJobEnterDoor",root,worksJobEnterDoor)

--function ped()
	--ped2 = createPed(152, 2258.4772949219, -1687.8142333984, 13.7)
	--setElementFrozen ( ped2, true )
	--setPedRotation(ped2, 180)
--end
--addEventHandler ( "onResourceStart", getRootElement(), ped )

function delPeds (ped1)
	setElementPosition ( ped1, 2258.4772949219, -1687.8142333984, 13.7 )
	setPedRotation(ped1, 180)
	setPedAnimation(ped1, nil, nil)
	setElementCollisionsEnabled(ped1, true)
end
function anim (ped1)
	setPedAnimation( ped1, "LOWRIDER", "lrgirl_l4_bnce")
	setElementPosition ( ped1, 2258.4772949219, -1687.8142333984, 12.8 )
	setPedRotation(ped1, 0)
end
function anim2 (source)
	setPedAnimation( source, "PAULNMAC","Piss_loop")
end
function noanim (ped1)
	setElementCollisionsEnabled(ped1, false)
	setPedRotation(ped1, 0)
	setPedAnimation(ped1, nil, nil)
end
function delPeds1 (source)
	setPedAnimation(source, nil, nil)
	setElementFrozen ( source, false )
	setElementPosition ( source, 2258.4462890625, -1689.1072998047, 13.7 )
end
