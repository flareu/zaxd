﻿sex = 5000 -- seks yapma maliyeti

razmer = 1  -- işaret boyutu

blipid = 21 -- blip id