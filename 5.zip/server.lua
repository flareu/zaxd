
setTimer(function ()
local amount = math.random(1000,1000) -- 1 dakikada verilecek maaş miktarı.
for id, player in ipairs(getElementsByType("player")) do
givePlayerMoney ( player, amount )
outputChatBox ( "#00FF00[SİSTE] Maaşınız Yatırlımıştır. #ff0000$"..amount.."#FF0000 ", player, 255, 255, 255, true ) -- Chate yazılan yazı.
end
end,60000,0)
