--- MTATR.NET
local entradaB = createMarker(1086.4340820313,-1803.6898193359,14.602746963501, "cylinder", 1, 255, 255, 255, 0)
local myBlip = createBlip( 1085.6364746094,-1800.0280761719,13.626179695129, 44, 0, 0, 0, 255, myPlayer )

addEventHandler( "onClientRender", root, function()
       local x, y, z = getElementPosition( entradaB )
       local Mx, My, Mz = getCameraMatrix(   )
        if ( getDistanceBetweenPoints3D( x, y, z, Mx, My, Mz ) <= 15 ) then
           local WorldPositionX, WorldPositionY = getScreenFromWorldPosition( x, y, z +1, 0.07 )
            if ( WorldPositionX and WorldPositionY ) then
			    dxDrawText("Bisiklet Kirala", WorldPositionX - 1, WorldPositionY + 1, WorldPositionX - 1, WorldPositionY + 1, tocolor(0, 0, 0, 255), 2.52, "default-bold", "center", "center", false, false, false, false, false)
			    dxDrawText("Bisiklet Kirala", WorldPositionX - 1, WorldPositionY + 1, WorldPositionX - 1, WorldPositionY + 1, tocolor(255, 255, 255, 255), 2.50, "default-bold", "center", "center", false, false, false, false, false)
            end
      end
end 
)
---------------------------------------------

function centerWindow(center_window)
    local screenW,screenH=guiGetScreenSize()
    local windowW,windowH=guiGetSize(center_window,false)
    local x,y = (screenW-windowW)/2,(screenH-windowH)/2
    guiSetPosition(center_window,x,y,false)
end

wndArenda = guiCreateWindow(0,0,500,150,"Bisiklet Kirala",false)
centerWindow(wndArenda)
guiSetVisible(wndArenda,false)

label1 = guiCreateLabel(0,30,490,480, "Bisiklet kiralama ücreti : \n500 $$ \n5 Dakika sonra Bisikletiniz yok olur.\nİyi oyunlar.", false, wndArenda)
guiSetFont(label1, "default-bold-small")
guiLabelSetHorizontalAlign(label1, "center", false)

local btn1 = guiCreateButton(20,100,200,35,"Kirala",false,wndArenda)
local btn2 = guiCreateButton(280,100,200,35,"Kapat",false,wndArenda)

addEventHandler('onClientGUIClick',wndArenda,function()
    if source == btn1 then
        triggerServerEvent("onPlayerUseCustomPickup", localPlayer)
        guiSetVisible(wndArenda,false)
        showCursor(false)
    elseif source == btn2 then
        guiSetVisible(wndArenda,false)
        showCursor(false)
    end
end)

function changeArendaMenuState()
    guiSetVisible(wndArenda,true)
    showCursor(true)
end
addEvent("changeArendaMenuState", true)
addEventHandler("changeArendaMenuState", getRootElement(), changeArendaMenuState)
--- MTATR.NET