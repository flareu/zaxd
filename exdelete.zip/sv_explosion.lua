local blowTimers = {}

function destroyBlownVehicle()
	if source and getElementType(source) == "vehicle" then
		local veh = source
		setTimer(function() destroyElement( veh ) end,3000,1)
	end
end

addEventHandler("onVehicleExplode", getRootElement(), destroyBlownVehicle)

function destroyOldVehicle ( ply,seat )
    if #getVehicleOccupants(source) == 0 then
		local veh = source
		blowTimers[source] = setTimer(function() destroyElement( veh ) end,1800000,1)
	end
end
addEventHandler ( "onVehicleExit", getRootElement(), destroyOldVehicle )

function destroyTimerForOldVehicle ( ply,seat )
    if #getVehicleOccupants(source) == 0 then
		if blowTimers[source] then
			killTimer(blowTimers[source]) 
		end
	end
end
addEventHandler ( "onVehicleEnter", getRootElement(), destroyTimerForOldVehicle )