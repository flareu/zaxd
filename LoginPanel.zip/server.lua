function loginPlayer (username, password, remember)
    if not (username == "") then
        if not (password == "") then
            local account = getAccount (username, password)
            if (account ~= false) then
				logIn (source, account, password)
				triggerClientEvent (source, "closePanel", getRootElement ())
				triggerClientEvent (source, "cNotification", getRootElement (), "Login", "Başarılı giriş.")
				if remember == true then
					triggerClientEvent(source,"saveLoginToXML",getRootElement(),username,password)
				else
					triggerClientEvent(source,"resetSaveXML",getRootElement(),username,password)
				end
			else 
				triggerClientEvent (source, "cNotification", getRootElement (), "Login", "Yanlış kullanıcı veya şifre.")
            end
		else
			triggerClientEvent (source, "cNotification", getRootElement (), "Login", "Şifrenizi girin.")
        end
	else
		triggerClientEvent (source, "cNotification", getRootElement (), "Login", "Kullanıcı adınızı girin.")
    end
end
addEvent("loginPlayer", true)
addEventHandler("loginPlayer", getRootElement(), loginPlayer)

function registerPlayer (usernameR, passwordR, passwordConfirmR)
	local serial = getPlayerSerial (source)
	local otherAccounts = getAccountsBySerial (serial)
	if #otherAccounts == 0 then
		if not (usernameR == "") then
			if not (passwordR == "") then
				if (passwordR == passwordConfirmR) then
					local account = getAccount (usernameR, passwordR)
					if (account == false) then
						local accountAdded = addAccount (tostring (usernameR),tostring (passwordR))
						if (accountAdded) then
							triggerClientEvent (source, "closeRegister", getRootElement ())
							triggerClientEvent (source, "cNotification", getRootElement (), "Login", "Kayıt oldunuz.")
						else
							triggerClientEvent (source, "cNotification", getRootElement (), "Register", "Bu kullanıcı zaten mevcut.")
						end
					else
						triggerClientEvent (source, "cNotification", getRootElement (), "Register", "Bu kullanıcı adı bir oyuncu tarafından kullanılıyor.")
					end
				else
					triggerClientEvent (source, "cNotification", getRootElement (), "Register", "Şifreler eşleşmiyor.")
				end
			else
				triggerClientEvent (source, "cNotification", getRootElement (), "Register", "Lütfen şifenizi girin.")
			end
		else
			triggerClientEvent (source, "cNotification", getRootElement (), "Register", "Lütfen kullanıcı adınızı girin.")
		end
	else
		triggerClientEvent (source, "cNotification", getRootElement (), "Register", "Zaten bir hesabın var.")
	end
end
addEvent("registerPlayer", true)
addEventHandler("registerPlayer", getRootElement(), registerPlayer)